function confirmarEliminar() {
    var confirmacion = confirm("¿Estás seguro de que quieres eliminar este producto?");
    if (confirmacion) {
        alert("Producto eliminado"); 
    }
}